// Definimos la estructura de la tupla, indicando 
// el tipo de cada uno de los datos que va a contener.
let pais :[
    string, 
    string,
    number|string,
    string
];

// Asignamos los datos, que deben ser del tipo correspondiente.
pais = [
    "Argentina", 
    "Buenos Aires", 
    "44.664.694",
    "Español"
];

/* Se muestra la tupla completa */
console.log("Los datos del pais son:");
console.log(pais);

