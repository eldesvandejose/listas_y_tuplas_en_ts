/* Se declara la lista, con los índices y valores que deseemos. */
let cubo = {
    peso: 120, 
    largo: 200, 
    anchura: 100, 
    altura: 57,
    color: "rojo"
}

/* Se muestra la lista completa */
console.log("Los datos del cubo son:");
console.log(cubo);

/* Se recorre cada lista, mostrando el índice y valor de cada elemento. */
for (let i in cubo){
    console.log ("El", i, "del cubo es", cubo[i]);
}
